﻿
namespace VirtualRouter.Wlan.WinAPI
{
    //http://msdn.microsoft.com/en-us/library/ms706027%28VS.85%29.aspx
    public enum DOT11_RADIO_STATE
    {
        dot11_radio_state_unknown,
        dot11_radio_state_on,
        dot11_radio_state_off
    }
}
